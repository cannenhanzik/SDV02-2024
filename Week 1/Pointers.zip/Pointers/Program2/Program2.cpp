// Program2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include "PGM2.h"
#include <iostream>


int main()
{
    PGM2::generateAndProcessArray();
    return 0;
}
