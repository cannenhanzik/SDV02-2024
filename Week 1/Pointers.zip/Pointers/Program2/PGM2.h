#ifndef PGM2_H
#define	PGM2_H


namespace PGM2 {
	 void printIntAndPointers(int value, int* ptr);
	 void generateAndProcessArray();
}

#endif // PGM2_H





