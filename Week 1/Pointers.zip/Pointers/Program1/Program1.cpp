#include "PGM1.h";

int main()
{
    PGM1::generateAndPrint();
    return 0;
}


