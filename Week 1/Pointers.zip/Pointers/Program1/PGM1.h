#ifndef PGM1_H
#define PGM1_H

using namespace std;

namespace PGM1 {
	void generateAndPrint();
}

#endif // PGM1_H
